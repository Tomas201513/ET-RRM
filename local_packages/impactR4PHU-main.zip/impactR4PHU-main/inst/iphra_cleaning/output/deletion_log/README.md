Deletion Log Directory
