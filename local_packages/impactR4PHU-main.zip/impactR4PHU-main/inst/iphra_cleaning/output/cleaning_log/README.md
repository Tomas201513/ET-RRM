Cleaning Log Directory
