Enum Performance Directory
